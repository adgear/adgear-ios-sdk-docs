//
//  AGENSDate.h
//  AdGearEventManager
//
//  Created by Boulat on 2016-02-24.
//  Copyright © 2016 AdGear. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (AGENSDate)

+ (long)ageNow;

@end
