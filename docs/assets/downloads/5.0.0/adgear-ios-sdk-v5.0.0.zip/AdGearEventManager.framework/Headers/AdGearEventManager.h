//
//  AdGearEventManager.h
//  AdGearEventManager
//
//  Created by Boulat on 2015-11-25.
//  Copyright © 2015 AdGear. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AdGearEventManager.
FOUNDATION_EXPORT double AdGearEventManagerVersionNumber;

//! Project version string for AdGearEventManager.
FOUNDATION_EXPORT const unsigned char AdGearEventManagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdGearEventManager/PublicHeader.h>
#import <AdGearEventManager/AGEventManager.h>
#import <AdGearEventManager/AGEContext.h>
#import <AdGearEventManager/AGEBuildConstants.h>
#import <AdGearEventManager/AGENSURL.h>
#import <AdGearEventManager/AGENSString.h>
#import <AdGearEventManager/AGENSDictionary.h>
#import <AdGearEventManager/AGENSDate.h>
#import <AdGearEventManager/AGENSData.h>
