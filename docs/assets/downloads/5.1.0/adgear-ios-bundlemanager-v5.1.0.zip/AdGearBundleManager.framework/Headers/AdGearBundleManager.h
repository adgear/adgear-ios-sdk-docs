//
//  AdGearBundleManager.h
//  AdGearBundleManager
//
//  Created by Boulat on 2015-11-03.
//  Copyright © 2015 AdGear. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AdGearBundleManager.
FOUNDATION_EXPORT double AdGearBundleManagerVersionNumber;

//! Project version string for AdGearBundleManager.
FOUNDATION_EXPORT const unsigned char AdGearBundleManagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdGearBundleManager/PublicHeader.h>
#import <AdGearBundleManager/AGBundleManager.h>
#import <AdGearBundleManager/AGBBuildConstants.h>

